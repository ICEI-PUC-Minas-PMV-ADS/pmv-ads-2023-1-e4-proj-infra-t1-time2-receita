export const BASE_URL= 'https://freecipesbackend.azurewebsites.net/api';

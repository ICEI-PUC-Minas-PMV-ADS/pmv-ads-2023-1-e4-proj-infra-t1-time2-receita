import { API_BASE_URL } from './urls'; // Replace with your API base URL

export const uploadImage = async (imageUri) => {
  try {
    const formData = new FormData();
    formData.append('image', {
      uri: imageUri,
      name: 'image.jpg',
      type: 'image/jpeg',
    });

    const response = await fetch(`${API_BASE_URL}/upload`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Image upload failed');
    }

    const responseData = await response.json();
    return responseData.imageUrl; // Assuming the API returns the uploaded image URL
  } catch (error) {
    console.error('Image upload error:', error);
    throw error;
  }
};

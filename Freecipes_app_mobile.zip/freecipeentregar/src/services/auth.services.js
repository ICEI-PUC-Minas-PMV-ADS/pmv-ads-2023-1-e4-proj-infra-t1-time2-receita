import API from './webapi.services';
import { BASE_URL } from './urls';
import AsyncStorage from '@react-native-community/async-storage';
import { decode } from 'base-64';

export const register = async (param) => {
  console.log(param);
  try {
    return await API.post(`${BASE_URL}/Usuarios`, param).then(
      (response) => {
        return response.data;
      },
      (error) => {
        console.log(error);
        return null;
      }
    );
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const login = async (param) => {
  try {
    return await API.post(`${BASE_URL}/Usuarios/authenticate`, param).then(
      (response) => {
        var decoded = JSON.parse(decode(response.data.jwtToken.split('.')[1]));
        console.log(decoded);
        var dados = {
          id: decoded.nameid,
          nome: decoded.unique_name,
          email: decoded.email,
        };
        AsyncStorage.setItem('@TOKEN_KEY', response.data.jwtToken);
        AsyncStorage.setItem('@ID', dados.id);
        AsyncStorage.setItem('@NOME', dados.nome);
        AsyncStorage.setItem('@EMAIL', dados.email);
        return dados;
      },
      (error) => {
        console.log(error);
        return null;
      }
    );
  } catch (error) {
    console.log(error);
    return null;
  }
};

import React, { useState } from 'react';
import validator from 'validator';
import { TextInput, Button, ActivityIndicator } from 'react-native-paper';
import {
  Image,
  StyleSheet,
  View,
  Alert,
  Dimensions,
  StatusBar,
} from 'react-native';
import Container from '../components/Container';
import { Input, InputNumeric } from '../components/Input';

import { useNavigation } from '@react-navigation/native';
import { register } from '../services/auth.services';

const Register = () => {
  const navigation = useNavigation();

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [datacadastro] = useState(new Date());
  const [isRegister, setRegister] = useState(false);

  const verificarCampos = () => {
    if (nome == '') {
      Alert.alert('Atenção', 'Informe seu nome!');
    } else if (email == '' || !validator.isEmail(email)) {
      Alert.alert('Atenção', 'Informe um email valido!');
    } else if (senha == '' || senha.length < 6) {
      Alert.alert('Atenção', 'A senha deve conter no mínimo 6 caracteres!');
    } else {
      registrarUsuario();
    }
  };

  const registrarUsuario = () => {
    setRegister(true);
    register({
      nome: nome,
      senha: senha,
      email: email,
      datacadastro: datacadastro,
    }).then((res) => {
      console.log(res);

      if (res) {
        setRegister(false);
        Alert.alert('Atenção', 'Usuário Cadastrado com sucesso!', [
          { text: 'OK', onPress: () => navigation.goBack() },
        ]);
      } else {
        setRegister(false);
        Alert.alert('Atenção', 'Usuário não cadastrado! Erro');
      }
    });
  };

  return (
    <Container style={styles.container}>
      <StatusBar hidden={true} translucent={true} />
      <View>
        <Image
          source={require('../assets/BannerMobile.png')}
          style={styles.image}
        />
      </View>
      <View style={styles.formContainer}>
        <Input
          label="Nome"
          value={nome}
          onChangeText={(text) => setNome(text)}
          left={<TextInput.Icon name="account" />}
          style={styles.input}
          theme={{
            roundness: 50,
          }}
          underlineColorAndroid="transparent"
        />
        <Input
          label="Email"
          value={email}
          onChangeText={(text) => setEmail(text)}
          left={<TextInput.Icon name="email" />}
          style={styles.input}
          theme={{
            roundness: 50,
          }}
          underlineColorAndroid="transparent"
        />
        <InputNumeric
          label="Senha"
          value={senha}
          secureTextEntry
          onChangeText={(text) => setSenha(text)}
          left={<TextInput.Icon name="key" />}
          style={styles.input}
          theme={{
            roundness: 50,
          }}
          underlineColorAndroid="transparent"
        />
        {isRegister && (
          <View style={styles.activity}>
            <ActivityIndicator size="large" color="#00ff00" />
          </View>
        )}
        {!isRegister && (
          <Button
            style={styles.button}
            mode="contained"
            onPress={verificarCampos}
            contentStyle={styles.buttonContent}
            labelStyle={[styles.buttonLabel, { color: '#FFFFFF' }]}
            color="#F28D00">
            Registrar
          </Button>
        )}
        <Button
          style={styles.button}
          mode="contained"
          onPress={() => navigation.goBack()}
          contentStyle={styles.buttonContent}
          labelStyle={[styles.buttonLabel, { color: '#FFFFFF' }]}
          color="#F28D00">
          Voltar
        </Button>
      </View>
    </Container>
  );
};

const styles = StyleSheet.create({
  image: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height * 0.333,
  },
  container: {
    backgroundColor: '#FFF',
  },
  formContainer: {
    paddingHorizontal: 16,
    marginTop: 32,
  },
  input: {
    marginBottom: 16,
    borderRadius: 50,
  },
  activity: {
    marginVertical: 8,
    borderRadius: 60,
    backgroundColor: '#FFF',
  },
  button: {
    marginVertical: 8,
    borderRadius: 60,
    backgroundColor: '#F28D00',
  },
  buttonContent: {
    height: 48,
    borderRadius: 10,
  },
  buttonLabel: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default Register;

import React, { useState, useEffect } from 'react';
import validator from 'validator';
import { TextInput, Button, ActivityIndicator } from 'react-native-paper';
import {
  Image,
  StyleSheet,
  View,
  Alert,
  Dimensions,
  StatusBar,
} from 'react-native';
import Container from '../components/Container';
import { Input, InputNumeric } from '../components/Input';
import AsyncStorage from '@react-native-community/async-storage';

import { useNavigation } from '@react-navigation/native';
import { useUser } from '../contexts/UserContext';

import { login } from '../services/auth.services';

const Login = () => {
  const navigation = useNavigation();
  const { setSigned, setId, setNome, setEmail } = useUser();

  const [email, setEmail2] = useState('');
  const [senha, setSenha] = useState('');
  const [isLoading, setLoading] = useState(false);
  const [isLoadingToken, setLoadingToken] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem('@TOKEN_KEY').then((token) => {
      if(token){
        loginToken();
      }else{
        setLoadingToken(false);
      }
    });
  },[]);

  const loginToken = () => {
    setSigned(true);
    setLoadingToken(false);
  };

  const handleLogin = () => {
    if (email == '' || !validator.isEmail(email) || senha == '') {
      Alert.alert('Atenção', 'Preencha corretamente os campos!');
    } else {
      setLoading(true);
      login({
        email: email,
        senha: senha,
      }).then((res) => {
        if (res) {
          setSigned(true);
        } else {
          setLoading(false);
          Alert.alert('Atenção', 'Usuário ou senha inválidos!');
        }
      });
    }
  };

  return (
    <Container style={styles.container}>
      <StatusBar hidden={true} translucent={true} />
      {isLoadingToken && (
        <View style={styles.activityToken}>
          <ActivityIndicator size="large" color="#00ff00" />
        </View>
      )}

      {!isLoadingToken && (
        <>
          <View>
            <Image
              source={require('../assets/BannerMobile.png')}
              style={styles.image}
            />
          </View>

          <View style={styles.formContainer}>
            <Input
              label="Email"
              value={email}
              onChangeText={(text) => setEmail2(text)}
              left={<TextInput.Icon name="account" />}
              style={styles.input}
              theme={{
                roundness: 50,
              }}
              underlineColorAndroid="transparent"
            />
            <InputNumeric
              label="Senha"
              value={senha}
              secureTextEntry
              onChangeText={(text) => setSenha(text)}
              left={<TextInput.Icon name="key" />}
              style={styles.input}
              theme={{
                roundness: 50,
              }}
              underlineColorAndroid="transparent"
            />
            {isLoading && (
              <View style={styles.activity}>
                <ActivityIndicator size="large" color="#00ff00" />
              </View>
            )}

            {!isLoading && (
              <Button
                style={styles.button}
                mode="contained"
                onPress={handleLogin}
                contentStyle={styles.buttonContent}
                labelStyle={styles.buttonLabel}
                color="#FF8C00">
                Entrar
              </Button>
            )}
            <Button
              style={styles.button}
              mode="contained"
              onPress={() => navigation.navigate('Register')}
              contentStyle={styles.buttonContent}
              labelStyle={styles.buttonLabel}
              color="#FF8C00">
              Registrar
            </Button>
          </View>
        </>
      )}
    </Container>
  );
};

const styles = StyleSheet.create({
  image: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height * 0.333,
  },
  container: {
    backgroundColor: '#F0E68C',
  },
  formContainer: {
    paddingHorizontal: 16,
    marginTop: 32,
  },
  input: {
    marginBottom: 16,
    borderRadius: 50,
  },
  button: {
    marginVertical: 8,
    borderRadius: 60,
    backgroundColor: '#FF8C00',
  },
  activity: {
    marginVertical: 8,
    borderRadius: 60,
    backgroundColor: '#FFF',
  },
  activityToken: {
    marginVertical: 8,
    borderRadius: 60,
    backgroundColor: '#FFF',
    flex: 1,
    justifyContent: 'center',
  },
  buttonContent: {
    height: 48,
    borderRadius: 10,
  },
  buttonLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
  },
});

export default Login;

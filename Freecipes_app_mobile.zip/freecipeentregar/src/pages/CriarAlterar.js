import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { Text, TextInput, Appbar, Button, Image } from 'react-native-paper';
import { Picker } from '@react-native-picker/picker';
import Container from '../components/Container';
import Header from '../components/Header';
import Body from '../components/Body';
import * as ImagePicker from 'expo-image-picker';
import { uploadImage } from '../services/imageUpload.services';
import {
  useNavigation,
  useFocusEffect,
  useRoute,
} from '@react-navigation/native';
import { useUser } from '../contexts/UserContext';
import {
  updateReceita,
  insertReceita,
  deleteReceita,
} from '../services/receitas.services';

const CriarAlterar = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { item } = route.params ? route.params : {};

  const { id } = useUser();

  const [nome, setNome] = useState(null);
  const [descricao, setDescricao] = useState(null);
  const [categoria, setCategoria] = useState(0);
  const [tempo, setTempo] = useState(null);
  const [dificuldade, setDificuldade] = useState(0);
  const [rendimento, setRendimento] = useState(null);
  const [ingrediente, setIngrediente] = useState(null);
  const [etapa, setEtapa] = useState(null);
  const [dt_receita, setDt_receita] = useState(new Date());
  const [photo, setPhoto] = useState(null);

  useEffect(() => {
    if (item) {
      setNome(item.nome);
      setDescricao(item.descricao);
      setCategoria(item.categoria);
      setTempo(item.tempo.toString());
      setDificuldade(item.dificuldade);
      setRendimento(item.rendimento.toString());
      setIngrediente(item.ingrediente);
      setEtapa(item.etapa);
      setDt_receita(item.dt_receita);
      setPhoto(item.photo);
    }
  }, [item]);

  useFocusEffect(
    React.useCallback(() => {
      (async () => {
        if (Platform.OS !== 'web') {
          const { status } =
            await ImagePicker.requestMediaLibraryPermissionsAsync();
          if (status !== 'granted') {
            Alert.alert(
              'Permission Required',
              'Permission to access the camera roll is required!',
            );
          }
        }
      })();
    }, []),
  );

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.cancelled) {
      const imageUri = result.uri;
      const uploadedImageUrl = await uploadImage(imageUri);
      setPhoto(uploadedImageUrl);
    }
  };

  const criarAlterar = () => {
    if (item) {
      updateReceita({
        nome: nome,
        descricao: descricao,
        tempo: parseInt(tempo),
        categoria: categoria,
        dificuldade: dificuldade,
        rendimento: parseInt(rendimento),
        ingrediente: ingrediente,
        etapa: etapa,
        dt_receita: dt_receita,
        photo: photo,
        id: item.id,
        usuarioId: id,
      }).then((res) => {
        navigation.goBack();
      });
    } else {
      insertReceita({
        nome: nome,
        descricao: descricao,
        tempo: tempo,
        dificuldade: dificuldade,
        categoria: categoria,
        rendimento: rendimento,
        ingrediente: ingrediente,
        etapa: etapa,
        dt_receita: dt_receita,
        photo: photo,
        usuarioId: parseInt(id),
      }).then((res) => {
        navigation.goBack();
      });
    }
  };

  const excluir = () => {
    Alert.alert('Atenção', 'Tem certeza que deseja EXCLUIR esta Receita?', [
      {
        text: 'Cancelar',
        style: 'cancel',
      },
      {
        text: 'Sim, Deletar',
        onPress: () =>
          deleteReceita(item.id).then((res) => {
            navigation.goBack();
          }),
      },
    ]);
  };

  const confirmar = () => {
    if (item) {
      Alert.alert('Atenção', 'Tem certeza que deseja alterar esta Receita ?', [
        {
          text: 'Cancelar',
          style: 'cancel',
        },
        { text: 'Sim', onPress: () => criarAlterar() },
      ]);
    } else {
      criarAlterar();
    }
  };

  return (
    <Container style={styles.container}>
      <Header title={nome} goBack={() => navigation.goBack()}>
        <Appbar.Action icon="check" onPress={confirmar} />
        {item && <Appbar.Action icon="trash-can" onPress={excluir} />}
      </Header>
      <Body>
        <ScrollView contentContainerStyle={styles.contentContainer}>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Nome:</Text>
            <TextInput
              style={styles.input}
              editable
              maxLength={30}
              onChangeText={(text) => setNome(text)}
              value={nome}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Descrição:</Text>
            <TextInput
              style={styles.input}
              editable
              multiline
              numberOfLines={3}
              onChangeText={(text) => setDescricao(text)}
              value={descricao}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Ingredientes:</Text>
            <TextInput
              style={styles.input}
              editable
              multiline
              numberOfLines={3}
              onChangeText={(text) => setIngrediente(text)}
              value={ingrediente}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Etapas:</Text>
            <TextInput
              style={styles.input}
              editable
              multiline
              numberOfLines={3}
              onChangeText={(text) => setEtapa(text)}
              value={etapa}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Tempo de preparo:</Text>
            <TextInput
              style={styles.input}
              editable
              onChangeText={(text) => setTempo(text)}
              value={tempo}
              keyboardType="decimal-pad"
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={styles.label}>Rendimento (Pratos):</Text>
            <TextInput
              style={styles.input}
              editable
              onChangeText={(text) => setRendimento(text)}
              value={rendimento}
              keyboardType="decimal-pad"
            />
          </View>
          <View style={styles.pickerContainer}>
            <Text style={styles.label}>Nível de dificuldade:</Text>
            <Picker
              selectedValue={dificuldade}
              style={styles.picker}
              onValueChange={(itemValue) => setDificuldade(itemValue)}>
              <Picker.Item label="Fácil" value={0} />
              <Picker.Item label="Médio" value={1} />
              <Picker.Item label="Difícil" value={2} />
            </Picker>
          </View>
          <View style={styles.pickerContainer}>
            <Text style={styles.label}>Tipo de refeição:</Text>
            <Picker
              selectedValue={categoria}
              style={styles.picker}
              onValueChange={(itemValue) => setCategoria(itemValue)}>
              <Picker.Item label="Café da Manhã" value={0} />
              <Picker.Item label="Almoço/Jantar" value={1} />
              <Picker.Item label="Sobremesa" value={2} />
              <Picker.Item label="Lanche" value={3} />
            </Picker>
          </View>
          <View style={styles.photoContainer}>
            <Text style={styles.label}>Foto:</Text>
            {photo ? (
              <Image source={{ uri: photo }} style={styles.photoPreview} />
            ) : (
              <Button
                mode="contained"
                onPress={pickImage}
                style={styles.uploadButton}>
                Upload Photo
              </Button>
            )}
          </View>
        </ScrollView>
      </Body>
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FF8C00',
  },
  contentContainer: {
    padding: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#fff',
    padding: 8,
    borderRadius: 4,
  },
  pickerContainer: {
    marginBottom: 16,
  },
  picker: {
    height: 50,
    backgroundColor: '#fff',
    borderRadius: 4,
  },
  photoContainer: {
    marginBottom: 16,
  },
  photoPreview: {
    width: 200,
    height: 200,
    borderRadius: 4,
    marginBottom: 8,
  },
  uploadButton: {
    borderRadius: 4,
  },
});

export default CriarAlterar;

import React, { useEffect, useState, localStorage } from 'react';
import { FlatList, View, StyleSheet } from 'react-native';
import { List, Text, Appbar } from 'react-native-paper';
import { FAB } from '@rneui/themed';
import AsyncStorage from '@react-native-community/async-storage';

import Header from '../components/Header';
import Container from '../components/Container';
import Body from '../components/Body';

import { useNavigation, useIsFocused } from '@react-navigation/native';
import { useUser } from '../contexts/UserContext';
import { getReceitas } from '../services/receitas.services';
import { getUsuario } from '../services/usuario.services';
import Carousel from './Carousel';

const Receitas = () => {
  const navigation = useNavigation();
  const isFocused = useIsFocused();

  const { setNome, setEmail, setSigned, setId, nome, id, email } = useUser();
  const [receitas, setReceitas] = useState([]);

  useEffect(() => {
    AsyncStorage.getItem('@ID').then((id1) => {
      getUsuario(id1).then((dados) => {
        setId(dados.id);
        setNome(dados.nome);
        setEmail(dados.email);
      });
    });
    getReceitas().then((dados) => {
      setReceitas(dados);
      console.log(dados);
    });
  }, [isFocused]);

  const logout = () => {
    AsyncStorage.getAllKeys()
      .then((keys) => AsyncStorage.multiRemove(keys))
      .then(() => setSigned(false));
  };

  const renderItem = ({ item }) => (
    <List.Item
      title={item.nome}
      description={item.descricao}
      left={(props) => (
        <List.Icon
          {...props}
          color={
            item.dificuldade == 0
              ? 'green'
              : item.dificuldade == 2
              ? 'red'
              : 'orange'
          }
          icon="food"
        />
      )}
      right={(props) => (
        <Text {...props} style={{ alignSelf: 'center' }}>
          {item.tempo} min
        </Text>
      )}
      onPress={() => navigation.navigate('Detalhes', { item })}
    />
  );

  return (
    <Container style={styles.container}>
      <Header title={'Olá ' + nome}>
        <Appbar.Action icon="logout" color="red" onPress={logout} />
      </Header>
      <View style={styles.carouselContainer}>
        <Carousel />
      </View>
      <Body>
        <FlatList
          data={receitas}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
        <FAB
          style={styles.fab}
          small
          color="orange"
          icon={{ name: 'add', color: 'black' }}
          onPress={() => navigation.navigate('CriarAlterar')}
        />
      </Body>
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FF8C00',
  },
  carouselContainer: {
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
});

export default Receitas;

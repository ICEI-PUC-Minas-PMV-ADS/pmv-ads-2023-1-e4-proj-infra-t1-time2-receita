import React, { useState, useRef } from 'react';
import { StyleSheet, View, FlatList, Image, Dimensions } from 'react-native';

const DATA = [
  {
    image: 'https://cdn0.tudoreceitas.com/pt/posts/3/2/6/macarrao_com_calabresa_5623_600.webp'
  },
  {
    image: 'https://cdn0.tudoreceitas.com/pt/posts/7/9/6/carre_de_cordeiro_no_forno_2697_600.webp'
  },
  {
    image: 'https://static.itdg.com.br/images/640-420/f52f6ba16063650bfa218c672f28c978/224943-original.jpg'
  },
];

const { width } = Dimensions.get('window');

const Carousel = () => {
  const flatListRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(0);

  const handleIndexChanged = (index) => {
    setActiveIndex(index);
  };

  const renderItem = ({ item }) => (
    <View style={styles.carouselItem}>
      <Image
        source={{ uri: item.image }}
        style={styles.carouselImage}
        resizeMode='cover'
      />
    </View>
  );

  const handleScroll = (event) => {
    const offsetX = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(offsetX / width);
    handleIndexChanged(newIndex);
  };

  return (
    <View style={styles.carouselContainer}>
      <FlatList
        ref={flatListRef}
        data={DATA}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        renderItem={renderItem}
        keyExtractor={(_, index) => String(index)}
        onScroll={handleScroll}
        onMomentumScrollEnd={handleScroll}
      />
      <View style={styles.dotContainer}>
        {DATA.map((_, index) => (
          <View
            key={index}
            style={[styles.dot, index === activeIndex ? styles.activeDot : styles.passiveDot]}
          />
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  carouselContainer: {
    height: 200,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  carouselItem: {
    width,
    justifyContent: 'center',
    alignItems: 'center',
  },
  carouselImage: {
    width: '90%',
    height: '90%',
    borderRadius: 10,
  },
  dotContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginHorizontal: 5,
  },
  activeDot: {
    backgroundColor: '#FF8C00',
  },
  passiveDot: {
    backgroundColor: '#D3D3D3',
  },
});

export default Carousel;
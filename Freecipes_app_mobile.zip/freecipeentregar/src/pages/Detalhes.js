import React, { useState, useEffect } from 'react';
import { FlatList, View, StyleSheet, TouchableOpacity } from 'react-native';
import {
  RadioButton,
  Text,
  TextInput,
  Button,
  Appbar,
} from 'react-native-paper';
import Container from '../components/Container';
import Header from '../components/Header';
import Body from '../components/Body';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/FontAwesome';

const Detalhes = ({ route }) => {
  const navigation = useNavigation();
  const { item } = route.params ? route.params : {};

  const tipo = () => {
    switch (item.categoria) {
      case 0:
        return 'Café da Manhã';
      case 1:
        return 'Almoço/Jantar';
      case 2:
        return 'Sobremesa';
      case 3:
        return 'Lanche';
      default:
        return 'Não especificado';
    }
  };

  const nivel = () => {
    switch (item.dificuldade) {
      case 0:
        return 'Fácil';
      case 1:
        return 'Médio';
      case 2:
        return 'Difícil';
      default:
        return 'Não especificado';
    }
  };

  return (
    <Container style={styles.container}>
      <Header title={item.nome} goBack={() => navigation.goBack()} />
      <Body>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Detalhes da Receita</Text>
        </View>
        <View style={styles.row}>
          <Icon name="cutlery" size={20} color="#000" style={styles.icon} />
          <Text style={styles.text}>Tipo de refeição: {tipo()}</Text>
        </View>
        <View style={styles.row}>
          <Icon name="info-circle" size={20} color="#000" style={styles.icon} />
          <Text style={styles.text}>Descrição: {item.descricao}</Text>
        </View>
        <View style={styles.row}>
          <Icon name="clock-o" size={20} color="#000" style={styles.icon} />
          <Text style={styles.text}>Tempo de preparo: {item.tempo} minutos</Text>
        </View>
        <View style={styles.row}>
          <Icon name="users" size={20} color="#000" style={styles.icon} />
          <Text style={styles.text}>Rendimento: {item.rendimento} prato(s)</Text>
        </View>
        <View style={styles.row}>
          <Icon name="star" size={20} color="#000" style={styles.icon} />
          <Text style={styles.text}>Nível: {nivel()}</Text>
        </View>
        <View style={styles.row}>
          <Icon name="list-ul" size={20} color="#000" style={styles.icon} />
          <Text style={styles.text}>Ingredientes: {item.ingrediente}</Text>
        </View>
        <View style={styles.row}>
          <Icon name="tasks" size={20} color="#000" style={styles.icon} />
          <Text style={styles.text}>Etapas: {item.etapa}</Text>
        </View>
      </Body>
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FF8C00',
  },
  section: {
    marginTop: 16,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  icon: {
    marginRight: 8,
  },
  text: {
    fontSize: 16,
  },
});

export default Detalhes;

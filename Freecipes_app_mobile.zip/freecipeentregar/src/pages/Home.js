import React, { useState, useEffect, useRef } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';

import { BottomNavigation, Text } from 'react-native-paper';

import MinhasReceitas from './MinhasReceitas';
import Receitas from './Receitas';

const Home = () => {
  const [index, setIndex] = useState(0);

  const [routes] = useState([
    { key: 'receitas', title: 'Receitas', icon: 'food' },
    { key: 'minhasreceitas', title: 'Minhas Receitas', icon: 'account' },
  ]);

  const renderScene = BottomNavigation.SceneMap({
    receitas: Receitas,
    minhasreceitas: MinhasReceitas,
  });

  return (
    <View style={styles.container}>
      <StatusBar style='auto' />

      <View style={styles.content}>
        <BottomNavigation
          navigationState={{ index, routes }}
          onIndexChange={setIndex}
          renderScene={renderScene}
          barStyle={{ backgroundColor: 'orange' }}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
});

export default Home;

import React, { createContext, useState, useContext } from 'react';

export const UserContext = createContext();

export default function UserProvider({ children }) {
  const [signed, setSigned] = useState(false);
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [id, setId] = useState(null);

  return (
    <UserContext.Provider
      value={{
        signed,
        setSigned,
        nome,
        setNome,
        email,
        setEmail,
        id,
        setId,
      }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  const { signed, setSigned, nome, setNome, email, setEmail, id, setId } =
    context;
  return { signed, setSigned, nome, setNome, email, setEmail, id, setId };
}

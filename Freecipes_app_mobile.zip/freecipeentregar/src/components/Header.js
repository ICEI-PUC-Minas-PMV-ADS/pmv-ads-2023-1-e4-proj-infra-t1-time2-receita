import React from 'react';
import { StyleSheet } from 'react-native';
import { Appbar } from 'react-native-paper';

const Header = ({ title, goBack, children }) => {
  return (
    <Appbar.Header style={styles.cor}>
      {goBack && <Appbar.BackAction onPress={goBack} />}
      <Appbar.Content title={title} />
      {children}
    </Appbar.Header>
  );
};

const styles = StyleSheet.create({
  cor: {
    backgroundColor: '#FFF',
  },
});

export default Header;

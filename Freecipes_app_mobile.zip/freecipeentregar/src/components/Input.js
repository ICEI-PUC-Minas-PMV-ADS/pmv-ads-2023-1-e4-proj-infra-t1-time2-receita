import React from 'react';
import { StyleSheet } from 'react-native';
import { TextInput } from 'react-native-paper';

export const InputNumeric = (props) => {
  return (
    <TextInput style={styles.input} keyboardType="decimal-pad" {...props} />
  );
};

export const Input = (props) => {
  return (
    <TextInput style={styles.input} keyboardType="text" {...props} />
  );
};

const styles = StyleSheet.create({
  input: {
    marginBottom: 8,
    backgroundColor: '#fff',
  },
});

